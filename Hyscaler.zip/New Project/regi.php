<?php
$servername = "localhost"; // Your MySQL server name (usually localhost)
$username = "root"; // Your MySQL username (default is root for XAMPP)
$password = ""; // Your MySQL password (default is empty for XAMPP)
$database = "registration_db"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch form data
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $usertype = $_POST['UserType'];

    // SQL query to insert data into the database
    $sql = "INSERT INTO userlogin (fullname, email, password, usertype) VALUES ('$fullname', '$email', '$password', '$usertype')";

    if ($conn->query($sql) === TRUE) {
   
        header("Location: Newadmin.php");   
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>
