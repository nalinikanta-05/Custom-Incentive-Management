<?php
$servername = "localhost"; // Your MySQL server name (usually localhost)
$username = "root"; // Your MySQL username (default is root for XAMPP)
$password = ""; // Your MySQL password (default is empty for XAMPP)
$database = "registration_db"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch form data
    $email = $_POST['Email'];
    $password = $_POST['Password'];
    $usertype = $_POST['UserType'];

    // SQL query to check if the user exists and matches the password
    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // User found, redirect to dashboard or home page
        header("Location: Newadmin.php");
    }
    else{
        header("Location: employee.php");
    }exit;
} 
else {
        $login_error = "Invalid email or password!";
}

// Close the connection
$conn->close();
?>
