<?php
// Database Configuration
$host = 'localhost';  // or your host
$dbname = 'registration_db';
$username = 'root';
$password = '';

// Creating PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("ERROR: Could not connect. " . $e->getMessage());
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $position = $_POST['position'] ?? 'Not Specified';  // Default if no input
    $salary = $_POST['salary'] ?? 0.00;  // Default if no input

    // SQL Insert Statement
    $sql = "INSERT INTO employee (firstname, lastname, email, position, salary) VALUES (?, ?, ?, ?, ?)";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$firstname, $lastname, $email, $position, $salary]);
        echo "Employee added successfully.";
    } catch(PDOException $e) {
        die("ERROR: Could not execute $sql. " . $e->getMessage());
    }
} 
else {
    // If the form is not submitted, display a message
    echo "No data submitted.";
}

?>

