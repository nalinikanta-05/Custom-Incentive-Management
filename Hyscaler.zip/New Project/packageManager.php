<?php
//require_once 'dbconfig.php'; // Database configuration file
// Database Configuration
$host = 'localhost'; // or your host
$dbname = 'registration_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("ERROR: Could not connect. " . $e->getMessage());
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'] ?? null; // Using null coalescing operator to handle absent values
    $holiday_name = $_POST['holiday_name'] ?? '';
    $duration_nights = $_POST['duration_nights'] ?? 0;
    $destination = $_POST['destination'] ?? '';
    $location = $_POST['location'] ?? '';
    $amenities = $_POST['amenities'] ?? '';
    $action = $_GET['action'] ?? 'add'; // Default action is add

    try {
        switch ($action) {
            case 'add':
                $sql = "INSERT INTO holiday_packages (id, holiday_name, duration_nights, destination, location, amenities) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$id, $holiday_name, $duration_nights, $destination, $location, $amenities]);
                header("Location: show.php");
                break;
            case 'edit':
                $sql = "UPDATE holiday_packages SET holiday_name=?, duration_nights=?, destination=?, location=?, amenities=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$holiday_name, $duration_nights, $destination, $location, $amenities, $id]);
                header("Location: dlt.php");
                break;
            case 'delete':
                $sql = "DELETE FROM holiday_packages WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$id]);
                header("Location: show.php");
                break;
            default:
                echo "Invalid action!";
                break;
        }
    } catch (PDOException $e) {
        die("ERROR: Could not execute $sql. " . $e->getMessage());
    }
} else {
    echo "No form submission detected.";
}
?>
