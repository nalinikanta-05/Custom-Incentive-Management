<?php
// Database Configuration
$host = 'localhost'; // or your host
$dbname = 'registration_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("ERROR: Could not connect. " . $e->getMessage());
}

// Check if the ID parameter is passed via GET request
if (isset($_GET['id']) && $_GET['id'] != '') {
    $id = $_GET['id'];

    try {
        // Retrieve package information based on the ID
        $stmt = $pdo->prepare("SELECT * FROM holiday_packages WHERE id = ?");
        $stmt->execute([$id]);
        $package = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$package) {
            echo "Package not found.";
        } else {
            // Display package information and confirmation form
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Package</title>
</head>
<body>
    <h2>Delete Package</h2>
    <p>Are you sure you want to delete the following package?</p>
    <p>ID: <?php echo $package['id']; ?></p>
    <p>Holiday Name: <?php echo $package['holiday_name']; ?></p>
    <p>Duration Nights: <?php echo $package['duration_nights']; ?></p>
    <p>Destination: <?php echo $package['destination']; ?></p>
    <p>Location: <?php echo $package['location']; ?></p>
    <p>Amenities: <?php echo $package['amenities']; ?></p>
    <form action="deletePackage.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $package['id']; ?>">
        <input type="submit" name="confirm_delete" value="Confirm Delete">
    </form>
    <a href="show.php">Cancel</a>
</body>
</html>
<?php
        }
    } catch(PDOException $e) {
        die("ERROR: Could not execute query. " . $e->getMessage());
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_delete'])) {
    // Process the deletion if the confirmation form is submitted
    $id = $_POST['id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM holiday_packages WHERE id = ?");
        $stmt->execute([$id]);
        echo "Package deleted successfully.";
    } catch(PDOException $e) {
        die("ERROR: Could not execute query. " . $e->getMessage());
    }
} else {
    echo "Invalid request.";
}
?>
