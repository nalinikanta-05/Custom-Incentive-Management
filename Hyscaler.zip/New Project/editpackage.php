<?php
// Include database connection settings
//require_once 'dbconfig.php'; // Assuming you have a separate file for the DB connection
$host = 'localhost'; // or your host
$dbname = 'registration_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("ERROR: Could not connect. " . $e->getMessage());
}
// Check for a valid package ID from the GET request or exit if none provided
if (isset($_GET['id']) && !empty(trim($_GET['id']))) {
    $id = trim($_GET['id']);

    // Prepare a select statement
    $sql = "SELECT * FROM holiday_packages WHERE id = ?";
    if ($stmt = $pdo->prepare($sql)) {
        $stmt->bindParam(1, $id, PDO::PARAM_INT);
        if ($stmt->execute()) {
            if ($stmt->rowCount() == 1) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $holiday_name = $row['holiday_name'];
                $duration_nights = $row['duration_nights'];
                $destination = $row['destination'];
                $location = $row['location'];
                $amenities = $row['amenities'];
            } else {
                // URL doesn't contain valid id parameter. Redirect to error page
                header("Location: error.php");
                exit();
            }
        } else {
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
    unset($stmt);
} else {
    // URL doesn't contain id parameter. Redirect to error page
    header("Location: error.php");
    exit();
}

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'Edit') {
    $holiday_name = $_POST['holiday_name'];
    $duration_nights = $_POST['duration_nights'];
    $destination = $_POST['destination'];
    $location = $_POST['location'];
    $amenities = $_POST['amenities'];

    $sql = "UPDATE holiday_packages SET holiday_name=?, duration_nights=?, destination=?, location=?, amenities=? WHERE id=?";
    if ($stmt = $pdo->prepare($sql)) {
        $stmt->execute([$holiday_name, $duration_nights, $destination, $location, $amenities, $id]);
        header("Location: show.php"); // Redirect to a page showing all packages
    } else {
        echo "Something went wrong. Please try again later.";
    }
    unset($stmt);
}

unset($pdo);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Holiday Package</title>
</head>
<body>
    <h2>Edit Holiday Package</h2>
    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
        <label>Holiday Name:</label>
        <input type="text" name="holiday_name" value="<?php echo $holiday_name; ?>"><br>

        <label>Duration (Nights):</label>
        <input type="number" name="duration_nights" value="<?php echo $duration_nights; ?>"><br>

        <label>Destination:</label>
        <input type="text" name="destination" value="<?php echo $destination; ?>"><br>

        <label>Location:</label>
        <input type="text" name="location" value="<?php echo $location; ?>"><br>

        <label>Amenities:</label>
        <textarea name="amenities"><?php echo $amenities; ?></textarea><br>

        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <input type="submit" value="Edit">
        <input type="hidden" name="action" value="Edit">
    </form>
    <a href="show.php">Back to list</a>
</body>
</html>
