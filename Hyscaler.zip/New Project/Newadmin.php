<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="Newadmin.css">
</head>
<body>
    <header class="dashboard-header">
        <h1>Admin</h1>
    </header>
    <div class="dashboard-main">
        <div class="dashboard-sidebar">
            <nav>
                <ul>
                    <li><a href="Holidays.html">Holiday Package</a></li>
                    <li><a href="add_employee.php">Employee Admin</a></li>
                    <li><a href="view_daily_sales.php">View Daily Sales</a></li>
                    <li><a href="view_package_claims.php">View Package Claims</a></li>
                    <li><a href="#settings">Send Notification</a></li>
                </ul>
            </nav>
        </div>
        <div class="dashboard-content">
            <section id="summary">
                <h2>Works</h2>
                <p>Overview of key metrics and latest alerts.</p>
            </section>
            <section id="reports">
                <h2>Reports</h2>
                <p>Latest financial and performance reports.</p>
            </section>
            <section id="analytics">
                <h2>Analytics</h2>
                <p>Deep dive into data analytics and trends.</p>
            </section>
            <section id="settings">
                <h2>Settings</h2>
                <p>Configuration and system settings.</p>
            </section>
        </div>
    </div>
    <div class="logout-container">
        <button onclick="handleLogout()" class="logout-button">Logout</button>
    </div>

    <script>
        function handleLogout() {
            // Here you would add your logic to logout the user.
            // For example, making an API call or redirecting to a server-side script.
            alert("Logout process initiated."); // Placeholder for demonstration
        }
    </script>
</body>
</html>
