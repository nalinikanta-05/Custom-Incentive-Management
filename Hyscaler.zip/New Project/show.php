<?php
// Database Configuration
$host = 'localhost'; // or your host
$dbname = 'registration_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("ERROR: Could not connect. " . $e->getMessage());
}

// Retrieve holiday packages from the database
try {
    $stmt = $pdo->query("SELECT * FROM holiday_packages");
    $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("ERROR: Could not execute query. " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Holiday Packages</title>
</head>
<body>
    <h2>Holiday Packages</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Holiday Name</th>
            <th>Duration Nights</th>
            <th>Destination</th>
            <th>Location</th>
            <th>Amenities</th>
        </tr>
        <?php foreach ($packages as $package): ?>
        <tr>
            <td><?php echo $package['id']; ?></td>
            <td><?php echo $package['holiday_name']; ?></td>
            <td><?php echo $package['duration_nights']; ?></td>
            <td><?php echo $package['destination']; ?></td>
            <td><?php echo $package['location']; ?></td>
            <td><?php echo $package['amenities']; ?></td>
        </tr>
        
        <?php endforeach; ?>
    </table>
</body>
</html>

