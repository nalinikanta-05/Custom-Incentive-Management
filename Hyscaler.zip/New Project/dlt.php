elseif ($action == 'Delete' && $id) {
    try {
        $sql = "DELETE FROM holiday_packages WHERE id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        // Optionally, you can check if any rows were affected
        $rowCount = $stmt->rowCount();
        if ($rowCount > 0) {
            echo "Data deleted successfully.";
        } else {
            echo "No matching data found for deletion.";
        }
        header("Location: dltpackage.php");
    } catch(PDOException $e) {
        die("ERROR: Could not execute $sql. " . $e->getMessage());
    }
}
